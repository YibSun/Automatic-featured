# Automating-feature-engineering
Some researches on Learning Feature Engineering ,see`./essay`

Run demo in `./codes`

You can manually adjust  parameters and place to hold data.

By default:

```shell
python AFE.py
python Training.py
python Validation.py
```

If you want to check the scale of useful and useless QSA.

```shell
# after running AFE.py
python CheckStatus.py
```

